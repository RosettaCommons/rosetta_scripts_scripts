#!/bin/bash
  
#SBATCH --time=2-0
#SBATCH --tasks-per-node=44
#SBATCH --ntasks=572
#SBATCH --distribution=cyclic:cyclic
#SBATCH -o log.txt
#SBATCH -e error.txt
#SBATCH -p 2112_queue

$MPI_HOME/bin/mpirun rosetta_scripts_jd3.mpiserialization.linuxgccrelease -parser:protocol rs_cluster.xml -job_definition_file jobdef.xml -use_truncated_termini -missing_density_to_jump -jd3:n_archive_nodes 2 -mpi_tracer_to_file mpi -linmem_ig 10 -out:pdb -overwrite -s trim_tree_relaxed.pdb

# END FILE HERE
