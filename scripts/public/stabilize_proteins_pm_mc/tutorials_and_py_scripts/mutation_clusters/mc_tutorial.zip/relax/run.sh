#!/bin/bash
  
#SBATCH --time=240
#SBATCH --tasks-per-node=44
#SBATCH --ntasks=44
#SBATCH --distribution=cyclic:cyclic
#SBATCH -o log.txt
#SBATCH -e error.txt
#SBATCH -p debug_queue

$MPI_HOME/bin/mpirun rosetta_scripts_jd3.mpiserialization.linuxgccrelease -parser:protocol rs_relax_cluster.xml -s trimmed_input_protein.pdb -nstruct 10 -out:file:scorefile score.sc -use_truncated_termini -missing_density_to_jump -jd3:n_archive_nodes 2 -mpi_tracer_to_file mpi -linmem_ig 10 -out:pdb -overwrite

# END FILE HERE
